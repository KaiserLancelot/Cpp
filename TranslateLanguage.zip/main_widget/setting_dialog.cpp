#include "setting_dialog.h"
#include "util.h"
#include <QEvent>

SettingDialog::SettingDialog(QWidget *parent)
	: QDialog(parent)
{
	this->setMinimumSize(300, 200);
	this->setWindowFlags(windowFlags()&~Qt::WindowContextHelpButtonHint);

	language_label = new QLabel();
	language_combo_box = new QComboBox();
	info_label = new QLabel();

    language_combo_box->addItem("chinese", QVariant::fromValue(UI_ZH));
    language_combo_box->addItem("english", QVariant::fromValue(UI_EN));

	QHBoxLayout *language_layout = new QHBoxLayout();
	language_layout->addStretch();
	language_layout->addWidget(language_label);
	language_layout->addWidget(language_combo_box);
	language_layout->addStretch();
	language_layout->setSpacing(5);
	language_layout->setContentsMargins(0, 0, 0, 0);

	QVBoxLayout *main_layout = new QVBoxLayout();
	main_layout->addWidget(info_label, 0, Qt::AlignCenter);
	main_layout->addLayout(language_layout);
	main_layout->setSpacing(10);
	main_layout->setContentsMargins(10, 10, 10, 10);

	this->setLayout(main_layout);
    this->translateUI();

    qRegisterMetaType<LANGUAGE>("LANGUAGE");
    connect(language_combo_box, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this, &SettingDialog::onIndexChanged);
}

SettingDialog::~SettingDialog()
{

}

void SettingDialog::changeEvent(QEvent *event)
{
    switch (event->type())
    {
    case QEvent::LanguageChange:
        translateUI();
        break;
    default:
        QDialog::changeEvent(event);
    }
}

void SettingDialog::translateUI()
{
	this->setWindowTitle(tr("setting dialog"));
	info_label->setText(tr("no brothers no programming"));
	language_label->setText(tr("language"));
	language_combo_box->setItemText(UI_ZH, tr("chinese"));
	language_combo_box->setItemText(UI_EN, tr("english"));
}

void SettingDialog::onIndexChanged()
{
    LANGUAGE language = language_combo_box->currentData().value<LANGUAGE>();

    emit switchLanguage(language);
}


void SettingDialog::loadConfig()
{
	QString language_value;
	QString language_suffix = QString("zh");
	LANGUAGE language = UI_ZH;
	bool is_read = Util::readInit(QString("./user.ini"), QString("language"), language_value);
	if(is_read)
	{
		language = (LANGUAGE)language_value.toInt();
		if(language == UI_EN)
		{
			language_suffix = QString("en");
		}
	}

	int count = language_combo_box->count();
    for(int i=0; i <count; i++)
	{
        if(language == i)
		{
            language_combo_box->setCurrentIndex(language);
            break;
        }
    }
}
