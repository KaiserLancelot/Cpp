<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>MainWidget</name>
    <message>
        <location filename="../main_widget.cpp" line="44"/>
        <source>main widget</source>
        <translation>主界面</translation>
    </message>
    <message>
        <location filename="../main_widget.cpp" line="45"/>
        <source>welcome to Qt</source>
        <translation>欢迎分享、交流，Qt群：</translation>
    </message>
    <message>
        <location filename="../main_widget.cpp" line="46"/>
        <source>setting</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../main_widget.cpp" line="47"/>
        <source>ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../main_widget.cpp" line="48"/>
        <source>cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>SettingDialog</name>
    <message>
        <location filename="../setting_dialog.cpp" line="57"/>
        <source>setting dialog</source>
        <oldsource>setting widget</oldsource>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../setting_dialog.cpp" line="59"/>
        <source>language</source>
        <translation>语言：</translation>
    </message>
    <message>
        <location filename="../setting_dialog.cpp" line="60"/>
        <source>chinese</source>
        <translation>中文</translation>
    </message>
    <message>
        <location filename="../setting_dialog.cpp" line="61"/>
        <source>english</source>
        <translation>英文</translation>
    </message>
    <message>
        <location filename="../setting_dialog.cpp" line="58"/>
        <source>no brothers no programming</source>
        <translation>无兄弟，不编程！</translation>
    </message>
</context>
</TS>
