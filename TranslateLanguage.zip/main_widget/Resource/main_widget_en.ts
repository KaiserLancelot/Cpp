<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWidget</name>
    <message>
        <location filename="../main_widget.cpp" line="44"/>
        <source>main widget</source>
        <translation>Main Widget</translation>
    </message>
    <message>
        <location filename="../main_widget.cpp" line="45"/>
        <source>welcome to Qt</source>
        <translation>Welcome to join us,QQ:</translation>
    </message>
    <message>
        <location filename="../main_widget.cpp" line="46"/>
        <source>setting</source>
        <translation>Setting</translation>
    </message>
    <message>
        <location filename="../main_widget.cpp" line="47"/>
        <source>ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../main_widget.cpp" line="48"/>
        <source>cancel</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>SettingDialog</name>
    <message>
        <location filename="../setting_dialog.cpp" line="57"/>
        <source>setting dialog</source>
        <oldsource>setting widget</oldsource>
        <translation>Setting Dialog</translation>
    </message>
    <message>
        <location filename="../setting_dialog.cpp" line="59"/>
        <source>language</source>
        <translation>Language:</translation>
    </message>
    <message>
        <location filename="../setting_dialog.cpp" line="60"/>
        <source>chinese</source>
        <translation>Chinese</translation>
    </message>
    <message>
        <location filename="../setting_dialog.cpp" line="61"/>
        <source>english</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="../setting_dialog.cpp" line="58"/>
        <source>no brothers no programming</source>
        <translation>No brothers,No promming!</translation>
    </message>
</context>
</TS>
